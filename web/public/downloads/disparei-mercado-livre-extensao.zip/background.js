chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action !== "gerarLink") return false;

  const urlTarget = String(request.url || "").trim();
  const isAmazon = /(^|\.)amazon\.com\.br/i.test(safeHostname(urlTarget)) || /amzn\.to/i.test(urlTarget);

  const runner = isAmazon
    ? gerarLinkNaAmazon(request)
    : gerarLinkNoMercadoLivre(request);

  runner
    .then((shortUrl) => {
      sendResponse({ success: true, shortUrl });
    })
    .catch((error) => {
      const prefix = isAmazon ? "[Amazon Extension]" : "[ML Extension]";
      console.error(`${prefix} Erro ao gerar link:`, error);
      sendResponse({ success: false, error: error.message || "Erro desconhecido no background." });
    });

  return true;
});

function safeHostname(url) {
  try {
    return new URL(url).hostname || "";
  } catch {
    return "";
  }
}

function safeSnippet(text) {
  return String(text || "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 300);
}

function extractCsrfToken(html) {
  const patterns = [
    /<meta[^>]+name=["']csrf-token["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+content=["']([^"']+)["'][^>]+name=["']csrf-token["']/i,
    /csrfToken["']?\s*[:=]\s*["']([^"']+)["']/i,
    /csrf-token["']?\s*[:=]\s*["']([^"']+)["']/i,
    /_csrf["']?\s*[:=]\s*["']([^"']+)["']/i,
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match && match[1]) return match[1].trim();
  }
  return "";
}

function looksLoggedOut(html) {
  const lower = html.toLowerCase();
  return (
    lower.includes('href="/afiliados/entrar"') ||
    lower.includes("nav-header-login") ||
    lower.includes("iniciar sessão") ||
    lower.includes("iniciar sesion") ||
    lower.includes("entrar na sua conta")
  );
}

// Percorre o JSON procurando o primeiro campo que pareça um link curto/afiliado do ML.
function findShortUrlDeep(node, depth = 0) {
  if (!node || depth > 6) return "";
  if (typeof node === "string") {
    const s = node.trim();
    if (/^https?:\/\/(?:[a-z0-9-]+\.)?(?:mercadolivre\.com|meli\.la|mercadolibre\.com)/i.test(s)) {
      return s;
    }
    return "";
  }
  if (Array.isArray(node)) {
    for (const item of node) {
      const found = findShortUrlDeep(item, depth + 1);
      if (found) return found;
    }
    return "";
  }
  if (typeof node === "object") {
    // Chaves preferenciais primeiro
    const preferred = [
      "short_url", "shortUrl", "short_link", "shortLink",
      "affiliate_url", "affiliateUrl", "affiliate_link", "affiliateLink",
      "url", "link",
    ];
    for (const key of preferred) {
      if (typeof node[key] === "string") {
        const found = findShortUrlDeep(node[key], depth + 1);
        if (found) return found;
      }
    }
    for (const key of Object.keys(node)) {
      const found = findShortUrlDeep(node[key], depth + 1);
      if (found) return found;
    }
  }
  return "";
}

// Procura recursivamente por qualquer string https://amzn.to/... no payload
// (JSON aninhado ou texto bruto). Independente do extractor do Mercado Livre.
function findAmznShortUrl(node, depth = 0) {
  if (node == null || depth > 6) return "";
  if (typeof node === "string") {
    const m = node.match(/https?:\/\/amzn\.to\/[A-Za-z0-9]+/i);
    return m ? m[0] : "";
  }
  if (Array.isArray(node)) {
    for (const item of node) {
      const found = findAmznShortUrl(item, depth + 1);
      if (found) return found;
    }
    return "";
  }
  if (typeof node === "object") {
    for (const key of Object.keys(node)) {
      const found = findAmznShortUrl(node[key], depth + 1);
      if (found) return found;
    }
  }
  return "";
}

function extractMlApiError(json) {
  if (!json || typeof json !== "object") return null;

  const urls = Array.isArray(json.urls) ? json.urls : [];
  const failed = urls.find((item) => item && typeof item === "object" && (item.error_code || item.message));
  if (failed) {
    return {
      code: failed.error_code,
      message: String(failed.message || "Erro retornado pelo Mercado Livre."),
      entity: String(failed.entity || ""),
    };
  }

  if (Number(json.total_error || 0) > 0 && Number(json.total_success || 0) === 0) {
    return {
      code: json.error_code,
      message: String(json.message || "O Mercado Livre não gerou nenhum link."),
      entity: "",
    };
  }

  return null;
}

async function readResponseBody(response) {
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    try {
      const json = await response.json();
      return { json, text: JSON.stringify(json) };
    } catch (e) {
      return { json: null, text: `<falha ao parsear JSON: ${e && e.message}>` };
    }
  }
  const text = await response.text();
  try {
    return { json: JSON.parse(text), text };
  } catch {
    return { json: null, text };
  }
}

async function gerarLinkNoMercadoLivre(request) {
  const urlProduto = String(request.url || "").trim();
  const tagAfiliado = String(request.tag || request.matt_word || "").trim();
  const mattTool = String(request.matt_tool || "").trim();

  if (!urlProduto) throw new Error("PRODUCT_URL_MISSING: URL do produto não recebida.");
  if (!tagAfiliado) throw new Error("MATT_WORD_MISSING: Etiqueta (matt_word) não recebida.");

  const responsePage = await fetch("https://www.mercadolivre.com.br/afiliados/linkbuilder", {
    method: "GET",
    credentials: "include",
    cache: "no-store",
  });

  if (responsePage.status === 401 || responsePage.status === 403) {
    throw new Error(`ML_SESSION_EXPIRED: Sessão do Mercado Livre expirada. Status ${responsePage.status}.`);
  }
  if (!responsePage.ok) {
    throw new Error(`ML_PANEL_ERROR: Falha ao acessar painel de afiliados. Status ${responsePage.status}.`);
  }

  const html = await responsePage.text();
  if (looksLoggedOut(html)) {
    throw new Error("ML_SESSION_MISSING: Faça login em mercadolivre.com.br/afiliados/linkbuilder antes de gerar links.");
  }

  const csrfToken = extractCsrfToken(html);
  if (!csrfToken) {
    throw new Error(`CSRF_NOT_FOUND: Token CSRF não encontrado no LinkBuilder. Trecho: ${safeSnippet(html)}`);
  }

  const apiPayload = { tag: tagAfiliado, urls: [urlProduto] };
  if (mattTool) apiPayload.matt_tool = mattTool;

  console.log("[BG] createLink payload:", JSON.stringify(apiPayload));

  const responseApi = await fetch(
    "https://www.mercadolivre.com.br/affiliate-program/api/v2/affiliates/createLink",
    {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        "x-csrf-token": csrfToken,
        "Referer": "https://www.mercadolivre.com.br/afiliados/linkbuilder",
        "Origin": "https://www.mercadolivre.com.br",
        "Accept": "application/json, text/plain, */*",
        "x-requested-with": "XMLHttpRequest",
      },
      body: JSON.stringify(apiPayload),
    }
  );

  const { json, text } = await readResponseBody(responseApi);
  console.log("[BG] createLink status:", responseApi.status, "body:", text);

  if (responseApi.status === 401 || responseApi.status === 403) {
    throw new Error(`ML_SESSION_EXPIRED: Sessão expirada ao criar link. Status ${responseApi.status}. Trecho: ${safeSnippet(text)}`);
  }
  if (!responseApi.ok) {
    throw new Error(`ML_API_ERROR: Erro na API de afiliados. Status ${responseApi.status}. Trecho: ${safeSnippet(text)}`);
  }

  const apiError = extractMlApiError(json);
  if (apiError) {
    const sent = `matt_word="${tagAfiliado}", matt_tool="${mattTool || "não enviado"}"`;
    if (String(apiError.code) === "109") {
      throw new Error(
        `ML_TAG_NOT_ASSOCIATED: A etiqueta enviada não pertence à conta afiliada logada no Mercado Livre. Enviado: ${sent}. Produto: ${apiError.entity || urlProduto}. Resposta: ${safeSnippet(text)}`,
      );
    }
    throw new Error(
      `ML_API_LINK_ERROR: ${apiError.message} Código: ${apiError.code || "sem código"}. Enviado: ${sent}. Resposta: ${safeSnippet(text)}`,
    );
  }

  const shortUrl = findShortUrlDeep(json) || findShortUrlDeep(text);
  if (!shortUrl) {
    throw new Error(`ML_API_UNEXPECTED_RESPONSE: Resposta sem link curto. JSON: ${String(text || "").slice(0, 300)}`);
  }

  return shortUrl;
}

// =====================================================================
// Amazon SiteStripe short-link generator
// =====================================================================

function cleanAmazonUrlWithTag(rawUrl, tag) {
  const u = new URL(rawUrl);
  // Zera query e hash e injeta apenas ?tag=
  u.search = "";
  u.hash = "";
  u.searchParams.set("tag", tag);
  return u.toString();
}

// Sinais fortes de página de login da Amazon (não confundir com nav tooltip).
function amazonHtmlIsLoginPage(html) {
  const lower = String(html || "").toLowerCase();
  return (
    lower.includes('id="ap_signin_form"') ||
    lower.includes('name="signin"') ||
    lower.includes('action="/ap/signin"')
  );
}

function amazonRespLooksLoggedOut(resp, html) {
  if (!resp) return false;
  const finalUrl = String(resp.url || "");
  if (/\/ap\/signin/i.test(finalUrl)) return true;
  if (html && amazonHtmlIsLoginPage(html)) return true;
  return false;
}

async function gerarLinkNaAmazon(request) {
  const urlProduto = String(request.url || "").trim();
  const amazonTag = String(request.amazon_tag || "").trim();

  if (!urlProduto) throw new Error("PRODUCT_URL_MISSING: URL do produto não recebida.");
  if (!amazonTag) throw new Error("AMAZON_TAG_MISSING: Tag de associado da Amazon (amazon_tag) não enviada.");

  let longUrl;
  try {
    longUrl = cleanAmazonUrlWithTag(urlProduto, amazonTag);
  } catch (err) {
    throw new Error(`AMAZON_URL_INVALID: URL do produto inválida (${err && err.message}).`);
  }

  // Probe da sessão do SiteStripe: /associados redireciona para /ap/signin se logado out.
  try {
    const probe = await fetch("https://www.amazon.com.br/associados", {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "follow",
    });
    if (probe.status === 401 || probe.status === 403) {
      throw new Error(`AMAZON_SESSION_EXPIRED: Sessão do associado expirada. Status ${probe.status}.`);
    }
    if (probe.ok) {
      const probeHtml = await probe.text();
      if (amazonRespLooksLoggedOut(probe, probeHtml)) {
        throw new Error("AMAZON_SESSION_MISSING: Faça login em amazon.com.br/associados antes de gerar links.");
      }
    }
  } catch (err) {
    if (err && String(err.message || "").startsWith("AMAZON_SESSION")) throw err;
    console.warn("[BG][Amazon] Probe /associados falhou, seguindo mesmo assim:", err && err.message);
  }

  // Endpoints conhecidos do SiteStripe. Prioriza o path pt-BR (/associados/)
  // com marketplaceId=526970, que é o que responde JSON { ok, shortUrl } hoje.
  const encLong = encodeURIComponent(longUrl);
  const attempts = [
    `https://www.amazon.com.br/associados/sitestripe/getShortUrl?longUrl=${encLong}&marketplaceId=526970`,
    `https://www.amazon.com.br/associados/sitestripe/getShortUrl?longUrl=${encLong}`,
    `https://www.amazon.com.br/associates/sitestripe/getShortUrl?longUrl=${encLong}&marketplaceId=A2Q3Y263D00KWC`,
    `https://www.amazon.com.br/associates/sitestripe/getShortUrl?longUrl=${encLong}`,
  ];

  // Headers alinhados ao node do n8n. Cookies vão automaticamente via
  // credentials: "include" (fetch proíbe setar Cookie manualmente).
  const headers = {
    "accept": "application/json, text/javascript, */*; q=0.01",
    "accept-language": "en-US,en;q=0.9",
    "x-requested-with": "XMLHttpRequest",
    "referer": "https://www.amazon.com.br/",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "sec-ch-ua-mobile": "?0",
  };

  let lastText = "";
  let lastStatus = 0;

  for (const attemptUrl of attempts) {
    const resp = await fetch(attemptUrl, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      headers,
    });

    lastStatus = resp.status;

    if (resp.status === 401 || resp.status === 403) {
      throw new Error(`AMAZON_SESSION_EXPIRED: Sessão expirada ao criar link. Status ${resp.status}.`);
    }
    if (/\/ap\/signin/i.test(String(resp.url || ""))) {
      throw new Error("AMAZON_SESSION_EXPIRED: SiteStripe redirecionou para login. Faça login em amazon.com.br/associados.");
    }

    const { json, text } = await readResponseBody(resp);
    lastText = text;
    console.log("[BG][Amazon] GET", attemptUrl, "status:", resp.status, "body:", String(text || "").slice(0, 400));

    if (!json && amazonHtmlIsLoginPage(text)) {
      throw new Error("AMAZON_SESSION_EXPIRED: SiteStripe devolveu página de login. Faça login em amazon.com.br/associados.");
    }

    if (!resp.ok) continue;
    if (json && json.ok === false) continue;

    const shortUrl = findAmznShortUrl(json) || findAmznShortUrl(text);
    if (shortUrl) return shortUrl;
  }

  throw new Error(
    `AMAZON_API_UNEXPECTED_RESPONSE: SiteStripe não retornou link curto (amzn.to). Status ${lastStatus}. Trecho: ${safeSnippet(lastText)}`,
  );
}


// =====================================================================
// Leitura de preço "vivo" do Mercado Livre usando a sessão do usuário
// =====================================================================

function parseMoney(raw) {
  if (raw == null) return null;
  let s = String(raw).trim();
  if (!s) return null;
  s = s.replace(/[^\d.,]/g, "");
  if (!s) return null;
  if (s.includes(",") && s.includes(".")) {
    s = s.replace(/\./g, "").replace(",", ".");
  } else if (s.includes(",")) {
    s = s.replace(",", ".");
  } else if (/\.\d{3}$/.test(s)) {
    s = s.replace(/\./g, "");
  }
  const n = Number(s);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function decodeEntities(text) {
  return String(text || "")
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function extractJsonLdOffers(html) {
  const out = [];
  const re = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(html))) {
    try {
      const parsed = JSON.parse(decodeEntities(m[1]).trim());
      const nodes = Array.isArray(parsed) ? parsed : [parsed];
      for (const node of nodes) {
        const offers = node && (node.offers || (node.mainEntity && node.mainEntity.offers));
        const list = Array.isArray(offers) ? offers : offers ? [offers] : [];
        for (const offer of list) {
          const price = parseMoney(offer && (offer.price || offer.lowPrice));
          if (price) out.push({ price, name: node.name || "" });
        }
      }
    } catch {
      /* ignore */
    }
  }
  return out;
}

function extractPreloadedPrices(html) {
  const result = {};
  const priceMatch = html.match(/"price"\s*:\s*\{[^{}]*"value"\s*:\s*([\d.]+)/);
  if (priceMatch) result.price = parseMoney(priceMatch[1]);
  const originalMatch = html.match(/"original_price"\s*:\s*([\d.]+)/);
  if (originalMatch) result.originalPrice = parseMoney(originalMatch[1]);
  const metaPrice = html.match(/itemprop=["']price["'][^>]*content=["']([\d.,]+)["']/i);
  if (!result.price && metaPrice) result.price = parseMoney(metaPrice[1]);
  return result;
}

function extractVisiblePrices(html) {
  const result = {};
  // Preço atual: <span class="andes-money-amount__fraction">1.234</span> + cents
  const current = html.match(
    /andes-money-amount--cents-superscript[\s\S]{0,400}?andes-money-amount__fraction["'][^>]*>([\d.,]+)<[\s\S]{0,200}?(?:andes-money-amount__cents["'][^>]*>(\d{2})<)?/i,
  );
  if (current) {
    const cents = current[2] ? `,${current[2]}` : "";
    result.price = parseMoney(`${current[1]}${cents}`);
  }
  if (!result.price) {
    const fallback = html.match(/andes-money-amount__fraction["'][^>]*>([\d.,]+)</i);
    if (fallback) result.price = parseMoney(fallback[1]);
  }
  // Preço original riscado (<s> ou classe previous)
  const previous = html.match(/<s[^>]*>[\s\S]{0,300}?andes-money-amount__fraction["'][^>]*>([\d.,]+)</i);
  if (previous) result.originalPrice = parseMoney(previous[1]);
  return result;
}

function extractTitle(html) {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i);
  if (og) return decodeEntities(og[1]).trim();
  const t = html.match(/<title>([\s\S]*?)<\/title>/i);
  return t ? decodeEntities(t[1]).trim() : "";
}

function extractImage(html) {
  const og = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i);
  if (og) return decodeEntities(og[1]).trim();
  const link = html.match(/<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i);
  return link ? decodeEntities(link[1]).trim() : "";
}

// Preço no Pix: o ML mostra um segundo valor no bloco de meios de pagamento.
function extractPixPrice(html) {
  // 1) Dados pré-carregados: bloco com "pix" próximo de um valor
  const preload = html.match(/"pix"[\s\S]{0,400}?"(?:amount|value|price)"\s*:\s*([\d.]+)/i);
  if (preload) {
    const v = parseMoney(preload[1]);
    if (v) return v;
  }
  // 2) Texto visível: "R$ 123,45 no Pix" / "com Pix"
  const visible = html.match(
    /andes-money-amount__fraction["'][^>]*>([\d.,]+)<[\s\S]{0,200}?(?:andes-money-amount__cents["'][^>]*>(\d{2})<)?[\s\S]{0,300}?(?:no|com)\s+Pix/i,
  );
  if (visible) {
    const cents = visible[2] ? `,${visible[2]}` : "";
    const v = parseMoney(`${visible[1]}${cents}`);
    if (v) return v;
  }
  return null;
}

async function lerPrecoMercadoLivre(request) {
  const url = String(request.url || "").trim();
  if (!url) throw new Error("PRODUCT_URL_MISSING: URL do produto não recebida.");

  const resp = await fetch(url, {
    method: "GET",
    credentials: "include",
    cache: "no-store",
    redirect: "follow",
    headers: {
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "accept-language": "pt-BR,pt;q=0.9",
    },
  });

  if (!resp.ok) {
    throw new Error(`ML_PAGE_ERROR: Falha ao abrir o produto. Status ${resp.status}.`);
  }

  const html = await resp.text();
  const finalUrl = String(resp.url || url);

  const lower = html.toLowerCase();
  if (lower.includes("tráfego suspeito") || lower.includes("trafego suspeito") || lower.includes("captcha")) {
    throw new Error("ML_BLOCKED: O Mercado Livre pediu verificação (captcha) nesta navegação.");
  }
  if (
    lower.includes("publicação pausada") ||
    lower.includes("publicacao pausada") ||
    lower.includes("anúncio pausado") ||
    lower.includes("produto indisponível") ||
    lower.includes("produto indisponivel")
  ) {
    return {
      url: finalUrl,
      title: extractTitle(html),
      image: extractImage(html),
      available: false,
      price: null,
      originalPrice: null,
      pricePix: null,
      discount: null,
      checkedAt: new Date().toISOString(),
      source: "extension-session",
    };
  }

  const preloaded = extractPreloadedPrices(html);
  const visible = extractVisiblePrices(html);
  const jsonLd = extractJsonLdOffers(html);

  const price = preloaded.price || visible.price || (jsonLd[0] && jsonLd[0].price) || null;
  let originalPrice = preloaded.originalPrice || visible.originalPrice || null;
  if (originalPrice && price && originalPrice <= price) originalPrice = null;

  if (!price) {
    throw new Error(`ML_PRICE_NOT_FOUND: Não foi possível ler o preço na página. Trecho: ${safeSnippet(html)}`);
  }

  const discount = originalPrice ? Math.round(((originalPrice - price) / originalPrice) * 100) : null;

  return {
    url: finalUrl,
    title: extractTitle(html),
    image: extractImage(html),
    available: true,
    price,
    originalPrice,
    pricePix: (() => {
      const pix = extractPixPrice(html);
      return pix && pix < price ? pix : null;
    })(),
    discount,
    checkedAt: new Date().toISOString(),
    source: "extension-session",
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!request || request.action !== "lerPreco") return false;

  lerPrecoMercadoLivre(request)
    .then((data) => sendResponse({ success: true, data }))
    .catch((error) => {
      console.error("[Preço] Erro:", error);
      sendResponse({ success: false, error: error.message || "Erro desconhecido ao ler preço." });
    });

  return true;
});
