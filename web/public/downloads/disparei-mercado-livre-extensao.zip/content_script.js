const EXTENSION_CONTEXT_INVALIDATED = "EXTENSION_CONTEXT_INVALIDATED";
const VARIANT = "v15";

// Só operamos nas origens oficiais do Catálogo Viral. Isso impede que outro
// site (inclusive em domínios compartilhados de preview) acione a extensão.
const ALLOWED_ORIGINS = [
  "https://catalogoviral.com",
  "https://www.catalogoviral.com",
  "https://catalogo.ananeves.com.br",
  "https://catalogoananeves.lovable.app",
  "https://id-preview--7317ef86-d0d6-4951-961c-befe49cd5bae.lovable.app",
];

const ORIGIN_ALLOWED = ALLOWED_ORIGINS.includes(window.location.origin);

// Coexistência com a extensão estável: se a versão de produção estiver
// instalada (ela anuncia ML_EXTENSION_READY sem `variant`), a BETA não
// responde a pedidos de link — evita gerar dois links para o mesmo clique.
// A leitura de preço (REQUEST_ML_PRICE) é exclusiva da BETA e sempre roda.
let legacyPresent = false;

function postReady() {
  if (!ORIGIN_ALLOWED) return;
  window.postMessage({ type: "ML_EXTENSION_READY", variant: VARIANT }, window.location.origin);
}

function postError(error) {
  if (!ORIGIN_ALLOWED) return;
  window.postMessage({ type: "ML_LINK_ERROR", error, variant: VARIANT }, window.location.origin);
}

function postSuccess(shortUrl) {
  if (!ORIGIN_ALLOWED) return;
  window.postMessage({ type: "ML_LINK_SUCCESS", shortUrl, variant: VARIANT }, window.location.origin);
}

function postPriceResult(payload) {
  if (!ORIGIN_ALLOWED) return;
  window.postMessage({ ...payload, variant: VARIANT }, window.location.origin);
}

function normalizeRuntimeError(message) {
  const raw = String(message || "");
  const lower = raw.toLowerCase();

  if (
    lower.includes("extension context invalidated") ||
    lower.includes("could not establish connection") ||
    lower.includes("receiving end does not exist")
  ) {
    return `${EXTENSION_CONTEXT_INVALIDATED}: A extensão foi recarregada ou reinstalada. Recarregue a página do catálogo.`;
  }

  return raw || "Erro desconhecido na comunicação com a extensão.";
}

function enviarParaBackground(payload) {
  return new Promise((resolve, reject) => {
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) {
      reject(
        new Error(
          `${EXTENSION_CONTEXT_INVALIDATED}: A extensão foi recarregada ou reinstalada. Recarregue a página do catálogo.`,
        ),
      );
      return;
    }
    try {
      chrome.runtime.sendMessage(payload, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(normalizeRuntimeError(lastError.message)));
          return;
        }

        resolve(response);
      });
    } catch (err) {
      reject(new Error(normalizeRuntimeError(err && err.message ? err.message : err)));
    }
  });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

window.addEventListener("message", async (event) => {
  if (!ORIGIN_ALLOWED) return;
  if (event.source !== window || !event.data) return;
  if (event.origin !== window.location.origin) return;
  const msgType = event.data.type;

  // Detecta a extensão estável para não duplicar a geração de links.
  if (msgType === "ML_EXTENSION_READY" && event.data.variant !== VARIANT) {
    legacyPresent = true;
    return;
  }

  if (msgType === "REQUEST_ML_PRICE") {
    const url = String(event.data.url || "").trim();
    const requestId = event.data.requestId || null;
    if (!url) {
      postPriceResult({ type: "ML_PRICE_ERROR", requestId, error: "PRODUCT_URL_MISSING: URL do produto não recebida." });
      return;
    }
    try {
      const response = await enviarParaBackground({ action: "lerPreco", url });
      if (response && response.success) {
        postPriceResult({ type: "ML_PRICE_SUCCESS", requestId, data: response.data });
      } else {
        postPriceResult({
          type: "ML_PRICE_ERROR",
          requestId,
          error: (response && response.error) || "BACKGROUND_EMPTY_RESPONSE: sem resposta do background.",
        });
      }
    } catch (err) {
      postPriceResult({
        type: "ML_PRICE_ERROR",
        requestId,
        error: err && err.message ? err.message : "Erro crítico ao ler preço.",
      });
    }
    return;
  }

  if (msgType !== "REQUEST_ML_LINK" && msgType !== "REQUEST_AMAZON_LINK") return;

  const isAmazon = msgType === "REQUEST_AMAZON_LINK";

  const url = String(event.data.url || "").trim();
  const tag = String(event.data.tag || event.data.matt_word || "").trim();
  const mattTool = String(event.data.matt_tool || "").trim();
  const amazonTag = String(event.data.amazon_tag || "").trim();

  if (!url) {
    if (legacyPresent) return;
    postError("PRODUCT_URL_MISSING: URL do produto não recebida pela extensão.");
    return;
  }

  // Dá uma janela para o READY da extensão estável (1.4.7 / 1.4.8) chegar
  // antes de decidirmos quem responde ao pedido de link. Na dúvida, a BETA
  // se cala: a extensão de produção continua sendo a dona da geração de links.
  if (!legacyPresent) await delay(900);
  if (legacyPresent) {
    console.log("[Extension] Extensão estável presente — ignorando pedido de link.");
    return;
  }

  if (isAmazon) {
    if (!amazonTag) {
      postError("AMAZON_TAG_MISSING: Tag de associado da Amazon (amazon_tag) não recebida pela extensão.");
      return;
    }
  } else {
    if (!tag) {
      postError("MATT_WORD_MISSING: Etiqueta (matt_word) não recebida pela extensão.");
      return;
    }
    if (!mattTool) {
      postError("MATT_TOOL_MISSING: ID da Ferramenta (matt_tool) não recebido pela extensão.");
      return;
    }
  }

  try {
    console.log("[Extension] Solicitando link", { isAmazon, url });
    const response = await enviarParaBackground({
      action: "gerarLink",
      url,
      tag,
      matt_word: tag,
      matt_tool: mattTool,
      amazon_tag: amazonTag,
    });

    if (response && response.success && response.shortUrl) {
      postSuccess(response.shortUrl);
      return;
    }

    postError(response && response.error ? response.error : "BACKGROUND_EMPTY_RESPONSE: O background não retornou um link.");
  } catch (err) {
    postError(err && err.message ? err.message : "Erro crítico na comunicação com a extensão.");
  }
});

postReady();
