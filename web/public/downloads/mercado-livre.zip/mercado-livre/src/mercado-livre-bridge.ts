const GENERATE_LINK_MESSAGE = "DISPAREI_ML_GENERATE_LINK";

type GenerateRequest = { type: typeof GENERATE_LINK_MESSAGE; inputUrl: string; affiliateTag?: string | null };

const sleep = (milliseconds: number) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function generateLink(request: GenerateRequest) {
  if (window.location.hostname !== "www.mercadolivre.com.br" || !window.location.pathname.startsWith("/afiliados/linkbuilder")) {
    throw new Error("Gerador oficial do Mercado Livre não está aberto.");
  }
  const input = document.querySelector<HTMLTextAreaElement>('textarea[placeholder*="mercadolivre"]');
  if (!input) throw new Error("Sua sessão Mercado Livre não está disponível. Reconecte sua conta.");
  if (request.affiliateTag) {
    const tagControl = document.querySelector<HTMLElement>('[role="combobox"][aria-label*="etiqueta" i]');
    const currentTag = tagControl?.textContent?.trim();
    if (currentTag && currentTag !== request.affiliateTag) throw new Error("A etiqueta selecionada no Mercado Livre foi alterada. Reconecte para atualizar.");
  }
  const valueSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
  valueSetter?.call(input, request.inputUrl);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  await sleep(200);
  const button = Array.from(document.querySelectorAll<HTMLButtonElement>("button")).find((item) => item.textContent?.trim() === "Gerar");
  if (!button || button.disabled) throw new Error("O Mercado Livre recusou a URL informada.");
  button.click();
  for (let attempt = 0; attempt < 80; attempt += 1) {
    await sleep(250);
    const output = Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("input,textarea"))
      .map((element) => element.value.trim()).find((value) => /^https:\/\/meli\.la\/[A-Za-z0-9_-]+$/i.test(value));
    if (output) {
      const tagControl = document.querySelector<HTMLElement>('[role="combobox"][aria-label*="etiqueta" i]');
      return { affiliateLink: output, affiliateTag: tagControl?.textContent?.trim() || null };
    }
    const alert = document.querySelector('[role="alert"]')?.textContent || "";
    if (/não pudemos|erro|inválid/i.test(alert)) throw new Error("O Gerador do Mercado Livre não conseguiu criar o link.");
  }
  throw new Error("O Gerador do Mercado Livre demorou mais que o esperado.");
}

chrome.runtime.onMessage.addListener((message: GenerateRequest, _sender, sendResponse) => {
  if (message?.type !== GENERATE_LINK_MESSAGE) return false;
  void generateLink(message).then((result) => sendResponse({ ok: true, ...result })).catch((error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "Falha no Gerador." }));
  return true;
});
