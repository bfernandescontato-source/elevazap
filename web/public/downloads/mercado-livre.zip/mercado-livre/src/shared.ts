export const CONNECTION_MESSAGE = "DISPAREI_ML_CONNECT";
export const CONNECTION_RESULT_MESSAGE = "DISPAREI_ML_CONNECTION_RESULT";
export const GENERATE_LINK_MESSAGE = "DISPAREI_ML_GENERATE_LINK";

export type ExtensionConfig = { backendOrigin: string; extensionToken: string; connectedAt: string };
export type GenerationJob = { id: string; input_url: string; affiliate_tag?: string | null; kind: "connection_test" | "conversion" };
