import { CONNECTION_MESSAGE, GENERATE_LINK_MESSAGE, type ExtensionConfig, type GenerationJob } from "./shared.js";

const CONFIG_KEY = "dispareiMercadoLivre";
const LINK_BUILDER_URL = "https://www.mercadolivre.com.br/afiliados/linkbuilder";
let processing = false;

async function config() {
  return (await chrome.storage.local.get(CONFIG_KEY))[CONFIG_KEY] as ExtensionConfig | undefined;
}

async function api(current: ExtensionConfig, path: string, init: RequestInit = {}) {
  const response = await fetch(`${current.backendOrigin}${path}`, {
    ...init,
    headers: { "content-type": "application/json", authorization: `Bearer ${current.extensionToken}`, ...(init.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "O Disparei recusou a operação da extensão.");
  return body;
}

async function waitForTab(tabId: number) {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === "complete") return;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error("O Portal do Mercado Livre demorou mais que o esperado.");
}

async function executeJob(job: GenerationJob) {
  const tab = await chrome.tabs.create({ url: LINK_BUILDER_URL, active: false });
  if (!tab.id) throw new Error("Não foi possível abrir o Gerador do Mercado Livre.");
  try {
    await waitForTab(tab.id);
    const response = await chrome.tabs.sendMessage(tab.id, { type: GENERATE_LINK_MESSAGE, inputUrl: job.input_url, affiliateTag: job.affiliate_tag });
    if (!response?.ok) throw new Error(response?.error || "Falha na geração do link.");
    return { affiliateLink: response.affiliateLink as string, affiliateTag: response.affiliateTag as string | null };
  } finally {
    await chrome.tabs.remove(tab.id).catch(() => undefined);
  }
}

async function poll() {
  if (processing) return;
  const current = await config();
  if (!current) return;
  processing = true;
  try {
    const { job } = await api(current, "/api/piloto-automatico/mercado-livre/extension/jobs");
    if (!job) return;
    try {
      const result = await executeJob(job);
      await api(current, `/api/piloto-automatico/mercado-livre/extension/jobs/${job.id}`, { method: "POST", body: JSON.stringify({ status: "completed", affiliate_link: result.affiliateLink, affiliate_tag: result.affiliateTag }) });
    } catch (error) {
      await api(current, `/api/piloto-automatico/mercado-livre/extension/jobs/${job.id}`, { method: "POST", body: JSON.stringify({ status: "failed", error_message: error instanceof Error ? error.message : "Falha no Mercado Livre." }) });
    }
  } finally { processing = false; }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== CONNECTION_MESSAGE) return false;
  void (async () => {
    const response = await fetch(`${message.backendOrigin}/api/piloto-automatico/mercado-livre/extension/connect`, {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ nonce: message.nonce })
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || "Não foi possível vincular a extensão.");
    await chrome.storage.local.set({ [CONFIG_KEY]: { backendOrigin: message.backendOrigin, extensionToken: body.extension_token, connectedAt: new Date().toISOString() } satisfies ExtensionConfig });
    await chrome.alarms.create("disparei-ml-poll", { periodInMinutes: 0.5 });
    await poll();
    return { ok: true };
  })().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "Falha na conexão." }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === "disparei-ml-poll") void poll(); });
chrome.runtime.onStartup.addListener(() => void poll());
chrome.runtime.onInstalled.addListener(() => void poll());
