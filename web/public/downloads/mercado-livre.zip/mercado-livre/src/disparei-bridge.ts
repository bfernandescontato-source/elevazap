const CONNECTION_MESSAGE = "DISPAREI_ML_CONNECT";
const CONNECTION_RESULT_MESSAGE = "DISPAREI_ML_CONNECTION_RESULT";

window.addEventListener("message", (event: MessageEvent) => {
  if (event.source !== window || event.origin !== window.location.origin || event.data?.type !== CONNECTION_MESSAGE) return;
  const { nonce, backendOrigin } = event.data;
  if (typeof nonce !== "string" || nonce.length < 32 || backendOrigin !== window.location.origin) return;
  chrome.runtime.sendMessage({ type: CONNECTION_MESSAGE, nonce, backendOrigin }, (response) => {
    window.postMessage({ type: CONNECTION_RESULT_MESSAGE, ok: Boolean(response?.ok), error: response?.error }, window.location.origin);
  });
});
