# Disparei — Mercado Livre

Ponte Manifest V3 entre a sessão Mercado Livre do próprio usuário e o Piloto Automático. A extensão não lê nem envia cookies, não faz disparos e não executa login.

## Desenvolvimento

1. Execute `npm install` e `npm run build` nesta pasta.
2. Em `chrome://extensions`, ative o modo do desenvolvedor.
3. Use **Carregar sem compactação** e escolha esta pasta.
4. Abra o Piloto Automático e clique em **Conectar Mercado Livre**.

Permissões: armazenamento local, alarmes, abas temporárias e acesso restrito aos domínios Mercado Livre e Disparei.
